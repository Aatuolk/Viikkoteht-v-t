package com.example.week11new;

import android.text.Editable;

public class Settings {
    int fontSize = 12;
    int width = 200;
    int height = 150;
    int nRows = 3;
    Boolean editable = true;


    public int getFontSize() {
        return fontSize;
    }

    public void setFontSize(int fontSize) {
        this.fontSize = fontSize;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getnRows() {
        return nRows;
    }

    public void setnRows(int nRows) {
        this.nRows = nRows;
    }

    public Boolean getEditable() {
        return editable;
    }

    public void setEditable(Boolean editable) {
        this.editable = editable;
    }

    private static Settings settings = new Settings();

    public static Settings getInstance() {
        return settings;
    }




}
