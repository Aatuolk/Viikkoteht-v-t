package com.example.week11new;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

import java.util.Set;

public class Main2Activity extends AppCompatActivity {

    EditText editFont;
    EditText editWidth;
    EditText editHeight;
    EditText editnRows;
    Switch aSwitch;
    EditText displayText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Settings settings = Settings.getInstance();

        editFont = findViewById(R.id.editText);
        editWidth = findViewById(R.id.editText2);
        editHeight = findViewById(R.id.editText4);
        editnRows = findViewById(R.id.editText5);
        aSwitch = findViewById(R.id.switch1);
        displayText = findViewById(R.id.editText6);

        editFont.setText(Integer.toString(settings.getFontSize()));
        editWidth.setText(Integer.toString(settings.getWidth()));
        editHeight.setText(Integer.toString(settings.getHeight()));
        editnRows.setText(Integer.toString(settings.getnRows()));
        aSwitch.setChecked(settings.getEditable());






    }


    @Override
    public void onBackPressed(){

        super.onBackPressed();

    }

    public void applySettings(View V){
        Settings settings = Settings.getInstance();
        settings.setFontSize(Integer.parseInt(editFont.getText().toString()));
        settings.setWidth(Integer.parseInt(editWidth.getText().toString()));
        settings.setHeight(Integer.parseInt(editHeight.getText().toString()));
        settings.setnRows(Integer.parseInt(editnRows.getText().toString()));
        settings.setEditable(aSwitch.isChecked());

    }
}
