package com.example.week9;

import android.view.View;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class PostEngine {
    private static ArrayList<Posti> postListFI = new ArrayList<Posti>();
    private static ArrayList<Posti> postListEE = new ArrayList<Posti>();

    public static ArrayList<Posti> getModifiedPostListFI() {
        return modifiedPostListFI;
    }

    public static void setModifiedPostListFI(ArrayList<Posti> modifiedPostListFI) {
        PostEngine.modifiedPostListFI = modifiedPostListFI;
    }

    public static ArrayList<Posti> getModifiedPostListEE() {
        return modifiedPostListEE;
    }

    public static void setModifiedPostListEE(ArrayList<Posti> modifiedPostListEE) {
        PostEngine.modifiedPostListEE = modifiedPostListEE;
    }

    private static ArrayList<Posti> modifiedPostListFI = new ArrayList<Posti>();
    private static ArrayList<Posti> modifiedPostListEE = new ArrayList<Posti>();


    private static PostEngine engine = new PostEngine();

    public static PostEngine getInstance() {
        return engine;
    }


    public void readXMLFI() {
        String name;
        String city;
        String address;
        String country;
        String pCode;
        String availability;
        String desc;
        try {

            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            String urlString = "http://iseteenindus.smartpost.ee/api/?request=destinations&country=FI&type=APT";
            Document doc = builder.parse(urlString);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getDocumentElement().getElementsByTagName("item");

            for (int i = 0; i < nList.getLength(); i++) {
                Node node = nList.item(i);

                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    name = element.getElementsByTagName("name").item(0).getTextContent();
                    city = element.getElementsByTagName("city").item(0).getTextContent();
                    address = element.getElementsByTagName("address").item(0).getTextContent();
                    country = element.getElementsByTagName("country").item(0).getTextContent();
                    pCode = element.getElementsByTagName("postalcode").item(0).getTextContent();
                    availability = element.getElementsByTagName("availability").item(0).getTextContent();
                    desc = element.getElementsByTagName("description").item(0).getTextContent();

                    Posti posti = new Posti(name, city, address, country, pCode, availability, desc);
                    addToFIList(posti);

                }
            }
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }

    }

    public void readXMLEE() {
        String name;
        String city;
        String address;
        String country;
        String pCode;
        String availability;
        String desc;
        try {

            DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            String urlString = "http://iseteenindus.smartpost.ee/api/?request=destinations&country=EE&type=APT";
            Document doc = builder.parse(urlString);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getDocumentElement().getElementsByTagName("item");

            for (int i = 0; i < nList.getLength(); i++) {
                Node node = nList.item(i);

                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    name = element.getElementsByTagName("name").item(0).getTextContent();
                    city = element.getElementsByTagName("city").item(0).getTextContent();
                    address = element.getElementsByTagName("address").item(0).getTextContent();
                    country = element.getElementsByTagName("country").item(0).getTextContent();
                    pCode = element.getElementsByTagName("postalcode").item(0).getTextContent();
                    availability = element.getElementsByTagName("availability").item(0).getTextContent();
                    desc = element.getElementsByTagName("description").item(0).getTextContent();

                    Posti posti = new Posti(name, city, address, country, pCode, availability, desc);
                    addToEEList(posti);

                }
            }
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        }

    }

    public void setPostlistFI(ArrayList<Posti> lista) {
        this.postListFI = lista;
    }

    public void createModifiedPostListFI(int day){
        ArrayList<Posti> list = getPostListFI();
        ArrayList<Posti> nlist = new ArrayList<Posti>();
        for (Posti posti : list){
            try {
                parseOpeningHours(posti);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            Date[][] openinghours = posti.getOpeninghours();
            if (openinghours[day][0] != null){
                nlist.add(posti);
                System.out.println("Lisätty listaan....!!!:!:!:!::!:");
            }
        } setModifiedPostListFI(nlist);
    }

    public static ArrayList<Posti> getPostListFI() {
        return postListFI;
    }

    public void setPostlistEE(ArrayList<Posti> lista) {
        this.postListEE = lista;
    }

    public static ArrayList<Posti> getPostListEE() {
        return postListEE;
    }


    public void addToFIList(Posti newPost) {
        ArrayList<Posti> list = getPostListFI();
        list.add(newPost);
        setPostlistFI(list);
    }

    public void addToEEList(Posti newPost) {
        ArrayList<Posti> list = getPostListEE();
        list.add(newPost);
        setPostlistEE(list);
    }

    public void parseOpeningHours(Posti p) throws ParseException {
        String ava = p.getAvailability();
        Date[][] hours = new Date[7][2];
        SimpleDateFormat formatter = new SimpleDateFormat("HH.mm");


        if (p.getCountry().equalsIgnoreCase("FI")) {
            String[] tokens = ava.split("[, ]");
            for (int i = 0; i < tokens.length; i++) {
                if (tokens[i].equalsIgnoreCase("ma-pe")) {
                    for (int k = 0; k < 5; k++){
                        hours[k][0] = formatter.parse(tokens[i + 1]);
                        hours[k][1] = formatter.parse(tokens[i + 3]);
                    }


                } if (tokens[i].equalsIgnoreCase("ma-la")) {
                    for (int k = 0; k < 6; k++){
                        hours[k][0] = formatter.parse(tokens[i + 1]);
                        hours[k][1] = formatter.parse(tokens[i + 3]);
                    }

                } if (tokens[i].equalsIgnoreCase("ma-su")) {
                    for (int k = 0; k < 7; k++){
                        hours[k][0] = formatter.parse(tokens[i + 1]);
                        hours[k][1] = formatter.parse(tokens[i + 3]);
                    }

                } if (tokens[i].equalsIgnoreCase("la-su")) {
                    for (int k = 5; k < 7; k++){
                        hours[k][0] = formatter.parse(tokens[i + 1]);
                        hours[k][1] = formatter.parse(tokens[i + 3]);
                    }

                } if (tokens[i].equalsIgnoreCase("la")) {
                    hours[5][0] = formatter.parse(tokens[i + 1]);
                    hours[5][1] = formatter.parse(tokens[i + 3]);


                } if (tokens[i].equalsIgnoreCase("su")) {
                    hours[6][0] = formatter.parse(tokens[i + 1]);
                    hours[6][1] = formatter.parse(tokens[i + 3]);

                }
            } p.setOpeninghours(hours);
        } else if (p.getCountry().equalsIgnoreCase("EE")){
            String[] tokens = ava.split("[, ]");
            for (int i = 0; i < tokens.length; i++) {

                if (tokens[i].equalsIgnoreCase("E-R")) {
                    String[] tokensEE = tokens[i+1].split("[-]");
                    for (int k = 0; k < 5; k++){
                        hours[k][0] = formatter.parse(tokensEE[0]);
                        hours[k][1] = formatter.parse(tokensEE[1]);
                    }

                } if (tokens[i].equalsIgnoreCase("E-L")) {
                    String[] tokensEE = tokens[i+1].split("[-]");
                    for (int k = 0; k < 6; k++){
                        hours[k][0] = formatter.parse(tokensEE[0]);
                        hours[k][1] = formatter.parse(tokensEE[1]);
                    }

                } if (tokens[i].equalsIgnoreCase("E-P")) {
                    String[] tokensEE = tokens[i+1].split("[-]");
                    for (int k = 0; k < 7; k++){
                        hours[k][0] = formatter.parse(tokensEE[0]);
                        hours[k][1] = formatter.parse(tokensEE[1]);
                    }

                } if (tokens[i].equalsIgnoreCase("L-P")) {
                    String[] tokensEE = tokens[i+1].split("[-]");
                    for (int k = 5; k < 7; k++){
                        hours[k][0] = formatter.parse(tokensEE[0]);
                        hours[k][1] = formatter.parse(tokensEE[1]);
                    }

                } if (tokens[i].equalsIgnoreCase("L")) {
                    String[] tokensEE = tokens[i+1].split("[-]");
                    hours[5][0] = formatter.parse(tokensEE[0]);
                    hours[5][1] = formatter.parse(tokensEE[1]);

                } if (tokens[i].equalsIgnoreCase("P")) {
                    String[] tokensEE = tokens[i+1].split("[-]");
                    hours[6][0] = formatter.parse(tokensEE[0]);
                    hours[6][1] = formatter.parse(tokensEE[1]);

                }
            } p.setOpeninghours(hours);
        }  //palauttaa postin aukioloajat
    }
}

