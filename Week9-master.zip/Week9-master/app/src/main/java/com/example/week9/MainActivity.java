package com.example.week9;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;


import java.text.ParseException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    PostEngine engine = PostEngine.getInstance();
    Spinner spinner;
    Spinner spinner2;
    Spinner spinner3;
    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        engine.readXMLFI();
        engine.readXMLEE();
        this.countrySpinner();
        this.weekDaySpinner();
    }
    public void setTextList(String s) {
        text.setText(s);

    }
    public String infoString(Posti post){
        String s = post.getName() + "  " + post.getCity() +"\n" + post.getAddress() + ",  " + post.getpCode() + "\n" + post.getAvailability() + "\n" + post.getDesc();
        return s;
    }

    public void countrySpinner(){
        spinner = (Spinner) findViewById(R.id.spinner);
        final ArrayList<String> clista = new ArrayList<String>();
        clista.add("Finland");
        clista.add("Estonia");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item, clista);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if (parent.getSelectedItem().toString().equalsIgnoreCase("Finland")){
                    postSpinnerFI();
                } else {
                    postSpinnerEE();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });}

    public void weekDaySpinner(){
        spinner3 = (Spinner) findViewById(R.id.spinner3);
        final ArrayList<String> wlista = new ArrayList<String>();
        //wlista.add("All");
        wlista.add("Monday");
        wlista.add("Tuesday");
        wlista.add("Wednesday");
        wlista.add("Thursday");
        wlista.add("Friday");
        wlista.add("Saturday");
        wlista.add("Sunday");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item, wlista);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner3.setAdapter(dataAdapter);
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                int choice = parent.getSelectedItemPosition();
                engine.createModifiedPostListFI(choice);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
    public void postSpinnerFI(){
            text = findViewById(R.id.textView);
            spinner2 = (Spinner) findViewById(R.id.spinner2);
            final ArrayList<Posti> lista = engine.getModifiedPostListFI();
            ArrayAdapter<Posti> dataAdapter = new ArrayAdapter<Posti>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item, lista);
            dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(dataAdapter);
            spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    Posti post = (Posti) parent.getItemAtPosition(position);
                    setTextList(infoString(post));
                    try {
                        engine.parseOpeningHours(post);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            }
        );}

    public void postSpinnerEE(){
        text = findViewById(R.id.textView);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        final ArrayList<Posti> lista = engine.getPostListEE();
        ArrayAdapter<Posti> dataAdapter = new ArrayAdapter<Posti>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item, lista);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Posti post = (Posti) parent.getItemAtPosition(position);
                setTextList(infoString(post));
                try {
                    engine.parseOpeningHours(post);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        }
        );}


    }



