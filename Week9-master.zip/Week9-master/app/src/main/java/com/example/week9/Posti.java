package com.example.week9;

import java.util.Date;

public class Posti {
    String name;
    String city;
    String address;
    String country;
    String pCode;
    String availability;
    String desc;
    Date[][] openinghours = new Date[7][2];

    public Date[][] getOpeninghours() {
        return openinghours;
    }

    public void setOpeninghours(Date[][] openinghours) {
        this.openinghours = openinghours;
    }



    public Posti(String n, String ci, String add, String co, String Code, String ava, String d){
        name = n;
        city = ci;
        address = add;
        country = co;
        pCode = Code;
        availability = ava;
        desc = d;
    }

    public String getName(){
        return name;
    }

    public String getCity(){
        return city;
    }
    public String getAddress(){
        return address;
    }
    public String getCountry(){
        return country;
    }
    public String getpCode(){
        return pCode;
    }
    public String getAvailability(){
        return availability;
    }
    public String getDesc(){
        return desc;
    }
    @Override
    public String toString() {
        return name + "  " + city;
    }



}
