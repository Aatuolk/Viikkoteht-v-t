package com.example.week8;



public class Bottle {

    private String name;

    private String manufacturer;

    private double total_energy;

    private double size;

    private double price;



    public Bottle(String nimi, String manuf, double totE, double koko, double prize){
        name = nimi;
        manufacturer = manuf;
        total_energy = totE;
        size = koko;
        price = prize;
    }
    @Override
    public String toString(){
        return name+" "+size+" "+price+ "€";
    }

    public String getName(){
        return name;
    }

    public String getManufacturer(){
        return manufacturer;
    }

    public double getEnergy(){
        return total_energy;
    }
    public double getPrice() {
        return price;
    }
    public double getSize() {
        return size;
    }

}




