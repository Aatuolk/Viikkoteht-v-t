package com.example.week8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;


public class MainActivity extends AppCompatActivity {
    BottleDispenser machine = BottleDispenser.getInstance();
    SeekBar seekBar;
    Spinner spinner;
    Context context;
    int amount;
    TextView text;
    Bottle choice;
    String bottleReceipt;
    String totalReceipt = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = findViewById(R.id.textView2);

        spinner = (Spinner) findViewById(R.id.spinner);
        final ArrayList<Bottle> lista = machine.getBottleList();
        ArrayAdapter<Bottle> dataAdapter = new ArrayAdapter<Bottle>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item, lista);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                choice = lista.get(position);
                String text = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), text, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        seekBar = findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                amount = progress;
                String x = "Money to be added: "+ amount;
                Toast.makeText(getApplicationContext(), x, Toast.LENGTH_LONG).show();

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        context = MainActivity.this;


    }

    public void add(View V){
        setTextList(machine.addMoney(amount));
        seekBar.setProgress(0);
    }

    public void buy(View V){
        bottleReceipt = "";
        setTextList(machine.buyBottle(choice));
        bottleReceipt = choice.getName() + " " + choice.getSize() + "     "+ choice.getPrice()+"\n";

        totalReceipt = totalReceipt+bottleReceipt;
    }


    public void withdraw(View V){
        setTextList(machine.returnMoney());
    }

    public void setTextList(String s) {
        text.setText(s);

    }
    public void getReceipt(View V){
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat form = new SimpleDateFormat("yyyy-dd-MM HH:mm:ss");
        String date = form.format(cal.getTime());
        String receipt = "***** RECEIPT *****\n";
        receipt += totalReceipt+date;

        try (OutputStreamWriter ows = new OutputStreamWriter(context.openFileOutput("receipt.txt", Context.MODE_PRIVATE))) {
            ows.write(receipt);
            setTextList("Receipt printed.");
            ows.close();
        } catch (IOException e) {
            Log.e("IOEXCEPTION", "Virhe kuitin kirjoituksessa.");
        }

    }



}
