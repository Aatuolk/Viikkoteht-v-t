package com.example.week8;




import android.widget.TextView;



import java.util.ArrayList;


public class BottleDispenser {

    private static int val;

    private int bottles;

    public ArrayList<Bottle> bottlelist;

    private double money;


    private static BottleDispenser dispenser = new BottleDispenser();

    public static BottleDispenser getInstance() {
        return dispenser;
    }



    public BottleDispenser() {

        bottles = 5;
        money = 0;

        ArrayList<Bottle> pottlelist = new ArrayList<Bottle>();

        Bottle aBottle = new Bottle("Pepsi Max","Pepsi",0.3,0.5, 1.8);
        pottlelist.add(aBottle);
        Bottle bBottle = new Bottle("Pepsi Max","Pepsi",1.2,1.5, 2.2);
        pottlelist.add(bBottle);
        Bottle cBottle = new Bottle("Coca-Cola Zero","Coca-Cola",0.3,0.5, 2.0);
        pottlelist.add(cBottle);
        Bottle dBottle = new Bottle("Coca-Cola Zero","Coca-Cola",1.2,1.5, 2.5);
        pottlelist.add(dBottle);
        Bottle eBottle = new Bottle("Fanta Zero","Coca-Cola",0.3,0.5, 1.95);
        pottlelist.add(eBottle);

        setBottlelist(pottlelist);

    }

    public void printlist(ArrayList<Bottle> lista) {
        Bottle currentBottle;
        ArrayList<Bottle> bottlelista = getBottleList();
        for (int i = 0; i < bottlelista.size(); i++) {
            currentBottle = bottlelista.get(i);
            System.out.println((i+1)+". Name: "+currentBottle.getName());
            System.out.println("	Size: "+currentBottle.getSize()+"	Price: "+currentBottle.getPrice());
        }
    }

    public void setBottlelist(ArrayList<Bottle> lista) {
        bottlelist = lista;
    }

    public ArrayList<Bottle> getBottleList() {
        return bottlelist;
    }



    public double getMoney() {
        return money;
    }

    public int getBottles() {
        return bottles;
    }



    public String addMoney(int x) {

        money = x + money;


        return "Klink! Added "+x+" € to the machine!";

    }



    public String buyBottle(Bottle val) {
        //Scanner scan = new Scanner(System.in);
        //printlist(bottlelist);
        //System.out.print("Your choice: ");
        //val = scan.nextInt();
        //Bottle currentBottle;
        ArrayList<Bottle> pulloLista = getBottleList();
        //currentBottle = pulloLista.get(val);

        if (getMoney() == 0 || getMoney() < val.getPrice()) {
            return ("Add money first!");
        } else if (getBottles() == 0) {
            return ("Out of bottles!");
        } else {
            money = (double) (money - val.getPrice());
            bottlelist.remove(val);
            return ("KACHUNK! "+val.getName()+" came out of the dispenser!");

        }


    }



    public String returnMoney() {

        String result = String.format("%.2f", money);
        money = 0;



        return "Klink klink. Money came out! You got "+result+"€ back";

    }

}


